
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import src.Card;
import src.CardGame;
import src.Deck;
import src.Player;


import java.util.ArrayDeque;



import org.junit.*;
public class PlayerTest {
    
    private CardGame mockCardGame = new CardGame();
    private Player p1;
    private Player p2;
    private Player p3;
    private Player p4;
    private Player p5;

    private Deck d1;
    private Deck d2;
    private Deck d3;
    private Deck d4;
    private Deck d5;


    public static void main(String[] args) {
        Result result = JUnitCore.runClasses(PlayerTest.class);

        for (Failure failure : result.getFailures()) {
            System.out.println(failure.getTestHeader() + " failed: " + failure.getMessage());
        }

        if(result.wasSuccessful()) {
            System.out.println("All tests passed!");
        } else{
            System.out.println("Some Test fail!");
        }
}


    @Before
    public void setup(){
        mockCardGame.startTest(5);

        p1 = mockCardGame.playerArr[0];
        p2 = mockCardGame.playerArr[1];
        p3 = mockCardGame.playerArr[2];
        p4 = mockCardGame.playerArr[3];
        p5 = mockCardGame.playerArr[4];

        d1 = mockCardGame.deckArr[0];
        d2 = mockCardGame.deckArr[1];
        d3 = mockCardGame.deckArr[2];
        d4 = mockCardGame.deckArr[3];
        d5 = mockCardGame.deckArr[4];
    }

    @Test
    public void validDateDeckLocation(){
        //Check for path that does not exists
        assertFalse(mockCardGame.validateFile("testing/deckThatdoesNotExists.txt", 5));
        System.out.println("Test pass for validate location of deck file");
    }
    @Test
    public void validDateDeckContent(){
        //Each deck have invalid content such as not enough card, invalid card value, and so on
        assertFalse(mockCardGame.validateFile("testing/invalidDeck.txt", 5));
        assertFalse(mockCardGame.validateFile("testing/invalidDeck2.txt", 5));
        assertFalse(mockCardGame.validateFile("testing/invalidDeck3.txt", 5));
        assertFalse(mockCardGame.validateFile("testing/invalidDeck4.txt", 5));
        assertFalse(mockCardGame.validateFile("testing/invalidDeck4.txt", 5));
        
       
        
        System.out.println("Test pass for validate content of deck file");
    }

    @Test
    public void validDatePlayerNumbers(){
        assertFalse(mockCardGame.validateNumberOfPlayer("-6"));
        assertFalse(mockCardGame.validateNumberOfPlayer("9a"));
        assertFalse(mockCardGame.validateNumberOfPlayer("_9"));
        assertFalse(mockCardGame.validateNumberOfPlayer("9 "));
        assertTrue(mockCardGame.validateNumberOfPlayer("5"));
        System.out.println("Test pass for validate amount of player");
    }

    @Test
    public void testDeckAssigning(){
        //Checking if we follow the convention that player Index i left deck is i - 1 and right deck is i, except for first player, as player player left deck is deck nth
        
        assertEquals(p1.getLeftDeck(), d5);
        assertEquals(p2.getLeftDeck(), d1);
        assertEquals(p3.getLeftDeck(), d2);
        assertEquals(p4.getLeftDeck(), d3);
        assertEquals(p5.getLeftDeck(), d4);

        assertEquals(p1.getRightDeck(), d1);
        assertEquals(p2.getRightDeck(), d2);
        assertEquals(p3.getRightDeck(), d3);
        assertEquals(p4.getRightDeck(), d4);
        assertEquals(p5.getRightDeck(), d5);

        System.out.println("Test pass for left and right deck assigning");
    }

    @Test
    public void testDeckLength(){   
        //At the start each deck must have 4 card
        assertTrue(d1.getCardList().size() == 4);
        assertTrue(d2.getCardList().size() == 4);
        assertTrue(d3.getCardList().size() == 4);
        assertTrue(d4.getCardList().size() == 4);
        assertTrue(d5.getCardList().size() == 4);

        System.out.println("Test pass for initial deck length");
    }

    @Test
    public void testDeckContent(){
        //Check if deck round robin is correct or not
        assertTrue(d1.getCardList().toString().equals("[0, 3, 1, 2]"));
        assertTrue(d2.getCardList().toString().equals("[0, 5, 6, 4]"));
        assertTrue(d3.getCardList().toString().equals("[4, 6, 0, 0]"));
        assertTrue(d4.getCardList().toString().equals("[3, 0, 0, 0]"));
        assertTrue(d5.getCardList().toString().equals("[5, 0, 1, 1]"));

        System.out.println("Test pass for initial deck content");

    }

    @Test
    public void testPlayerHandLength(){
        //Start of game must have 4 card
        assertTrue(p1.getPlayerCard().size() == 4);
        assertTrue(p2.getPlayerCard().size() == 4);
        assertTrue(p3.getPlayerCard().size() == 4);
        assertTrue(p4.getPlayerCard().size() == 4);
        assertTrue(p5.getPlayerCard().size() == 4);

        System.out.println("Test pass for playerHandLength");
    }

    @Test
    public void playerHandContent(){
        assertTrue(p1.getPlayerCard().toString().equals("[1, 0, 0, 6]"));
        assertTrue(p2.getPlayerCard().toString().equals("[3, 6, 3, 3]"));
        assertTrue(p3.getPlayerCard().toString().equals("[4, 4, 6, 1]"));
        assertTrue(p4.getPlayerCard().toString().equals("[2, 2, 6, 4]"));
        assertTrue(p5.getPlayerCard().toString().equals("[1, 1, 5, 4]"));

        System.out.println("Test pass for initial content in player hand");
    }



    @Test
    public void testWithDrawnCard(){
        Player p1 = mockCardGame.playerArr[0];
        Deck p1LeftDeck = p1.getLeftDeck();
        ArrayDeque<Card> deckQueue = p1LeftDeck.getCardList();
        Card topCard = deckQueue.getFirst();
        p1.withDrawnCard();
        assertFalse(deckQueue.contains(topCard));
        System.out.println("Test pass for removing top Card");
    }

    @Test
    public void testDiscardingCard(){
        Player p1 = mockCardGame.playerArr[1];
        Deck p1rightDeck = p1.getRightDeck();
        ArrayDeque<Card> deckQueue = p1rightDeck.getCardList();
        //The first card have an undesired value (card value != player Index)
        Card cardTobeRemoved = p1.getPlayerCard().get(0);

        //Making sure that the discarding card actually discard the first card in the player hand to the bottom of the right deck or not
        p1.discardingCard();
        assertEquals(cardTobeRemoved, deckQueue.getLast());
        System.out.println("Test for Discarding card to bottom of right deck pass");
    }




    
}
